

#ifdef USE_QUAL
if (pkgName == "qual")
{		
	return SWIGTYPE_p_SBMLExtensionNamespacesT_QualExtension_t;
}
#endif	

