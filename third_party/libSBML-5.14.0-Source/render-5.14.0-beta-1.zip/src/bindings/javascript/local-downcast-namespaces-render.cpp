

#ifdef USE_RENDER
if (pkgName == "render")
{		
	return SWIGTYPE_p_SBMLExtensionNamespacesT_RenderExtension_t;
}
#endif	

