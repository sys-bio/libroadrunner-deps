
#ifdef USE_RENDER
if (pkgName == "render")
{		
	return SWIGTYPE_p_RenderExtension;
}
#endif	

