
#ifdef USE_RENDER
RenderExtension::init();
#endif	

