#ifdef USE_MULTI
if (pkgName == "multi")
{
  return SWIGTYPE_p_SBMLExtensionNamespacesT_MultiExtension_t;
}
#endif // USE_MULTI 

