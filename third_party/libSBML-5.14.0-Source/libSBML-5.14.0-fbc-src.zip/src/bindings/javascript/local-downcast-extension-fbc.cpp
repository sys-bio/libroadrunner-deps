#ifdef USE_FBC
if (pkgName == "fbc")
{
  return SWIGTYPE_p_FbcExtension;
}
#endif // USE_FBC 

