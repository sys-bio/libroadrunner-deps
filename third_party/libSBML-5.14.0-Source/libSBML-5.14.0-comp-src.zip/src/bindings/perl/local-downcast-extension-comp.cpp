
#ifdef USE_COMP
if (pkgName == "comp")
{		
	return SWIGTYPE_p_CompExtension;
}
#endif	

