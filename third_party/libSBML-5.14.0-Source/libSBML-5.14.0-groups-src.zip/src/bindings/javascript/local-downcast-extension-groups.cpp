
#ifdef USE_GROUPS
if (pkgName == "groups")
{		
	return SWIGTYPE_p_GroupsExtension;
}
#endif	

