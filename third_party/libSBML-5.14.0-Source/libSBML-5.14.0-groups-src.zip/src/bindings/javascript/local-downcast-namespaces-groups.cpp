

#ifdef USE_GROUPS
if (pkgName == "groups")
{		
	return SWIGTYPE_p_SBMLExtensionNamespacesT_GroupsExtension_t;
}
#endif	

