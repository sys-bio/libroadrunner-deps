
#ifdef USE_REQUIREDELEMENTS

#include <sbml/packages/req/extension/ReqExtension.h>
#include <sbml/packages/req/extension/ReqSBasePlugin.h>
#include <sbml/packages/req/common/ReqExtensionTypes.h>
#include <sbml/packages/req/sbml/ChangedMath.h>

#endif // USE_REQUIREDELEMENTS 

