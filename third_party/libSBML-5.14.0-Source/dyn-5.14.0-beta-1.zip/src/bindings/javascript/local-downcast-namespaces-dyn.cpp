#ifdef USE_DYN
if (pkgName == "dyn")
{
  return SWIGTYPE_p_SBMLExtensionNamespacesT_DynExtension_t;
}
#endif // USE_DYN 

